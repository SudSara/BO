# BO(frontend) - API Project 

This project is belongs to BO - front office project

## Installation

Install MongoDb community edition above version 5.0 before run the application 

## MongoDb

- Post mongodb installation run below command in terminal/cmd:

```bash
  mongod
```

## BO Project

- Inside the BO project run below commands:

```bash
  npm install
```
```bash
  npm install -g nodemon 
```
```bash
  npm start
```
    