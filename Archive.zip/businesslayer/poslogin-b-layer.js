const { USER_SECURE_DATA, POS_USERS } = require('../helper/collection-name');
const getdb = require('../database/db').getDb;
const { ObjectId } = require('mongodb');

module.exports = { 
    v2(req) {
        return new Promise(async(resolve, reject) => {
            try{
            let response;
            const option = {
                user_name: req.body.user_name,
                password: req.body.password,
            };
            console.log(option)
            const query = [
                {
                $match: {
                    email: option.user_name,
                },
                },
                {
                $lookup: {
                    from: 'UserSecureData',
                    localField: '_id',
                    foreignField: 'store_id',
                    as: 'privatedata',
                },
                },
                {
                $project: {
                    name: 1,
                    phone_number: 1,
                    account_id: 1,
                    email: 1,
                    password: { $arrayElemAt: [ '$privatedata.password', 0 ] },
                    user_secure_id:{ $arrayElemAt: [ '$privatedata._id', 0 ] }
                },
                },
            ];
            getdb(POS_USERS)
            .aggregate(query)
            .toArray(async(err, result) => {
                if (err) {
                reject(err);
                }
                if (result.length == 1) {
                const user = result[0];
                const passwordMatch = user.password == option.password;
                const token_code = {
                    user_id: user._id,
                };
                if (!passwordMatch) {
                    response = {
                    success: false,
                    message: 'Invalid credentials PW',
                    };
                    resolve(response);
                } else {
                    try{
                    let account_data = await getdb(ACCOUNTS).findOne({"_id":ObjectId(user.account_id)});
                    let u_s_data = await getdb(USER_SECURE_DATA).find({account_id:ObjectId(user.account_id),"store_id":{'$exists': true},"logged_in":true}).toArray();
                    if(account_data.stores_count <= u_s_data.length){
                        return reject({success:false,message:'store login limit excied'})
                    }
                    const token_info = {
                        user: {
                        _id: user._id,
                        email: user.email,
                        },
                        token_code
                    };
                    const token = jwt.sign(
                        {
                        token_info,
                        },
                        'hG6j!68Mgd3r!',
                    );
                    await getdb(USER_SECURE_DATA).updateOne({_id:ObjectId(user.user_secure_id)},{$set:{token:token,last_login:new Date(),logged_in:true}});
                    resolve({
                        success: true,
                        token,
                        user: {
                        _id: user._id,
                        email: user.email
                        },
                    });
                    }catch(err){
                    reject(err);
                    }
                }
                } else {
                response = {
                    success: false,
                    message: 'Invalid credentials',
                };
                resolve(response);
                }
            });
            }catch(err){
            reject(err);
            }
        });
    }
}
