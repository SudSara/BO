module.exports = {
  ACCOUNTS: 'accounts',
  USER_SECURE_DATA: 'UserSecureData',
  STORES:'stores',
  CATEGORY:'category',
  USERS:'users',
  ROLES:'roles',
  CUSTOMERS:'customers',
  MENUITEMS:'menuitems',
  TAXES:'taxes',
  POS_USERS:"pos_users"
};
