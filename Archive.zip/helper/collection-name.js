module.exports = {
  ACCOUNTS: 'accounts',
  USER_SECURE_DATA: 'UserSecureData',
  STORES:'stores'
};
