const express = require('express');
const router = express.Router();
const loginBLayer = require('../businesslayer/poslogin-b-layer');

router.post('/authendicate/v1', (req, res, next) => {
  loginBLayer
    .v1(req)
    .then((response) => {
      res.send(response);
    })
    .catch((err) => {
      next(err);
    });
});

router.put('/account/:account_id/logout',(req,res,next)=>{
  loginBLayer.accountLogout(req).then((response)=>{
    res.send(response);
  }).catch(err=>{
    next(err);
  })
});
module.exports = router;
